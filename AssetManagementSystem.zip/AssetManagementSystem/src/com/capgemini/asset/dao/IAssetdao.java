package com.capgemini.asset.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.asset.bean.AssetBean;
import com.capgemini.asset.bean.AssetRequestBean;
import com.capgemini.asset.bean.AssetRequestFormBean;
import com.capgemini.asset.bean.UserBean;
import com.capgemini.asset.exception.AssetException;

public interface IAssetdao {
	public boolean dataAuthentication(UserBean a);
	public boolean updatePassword(String username,String password);
	public void addNewAsset(AssetBean as) throws SQLException, AssetException;
	public void modifyAssetDetails(AssetBean as,long oldAssetId) throws SQLException, AssetException;
	public ArrayList<AssetRequestBean> viewRequestDetails(int requestId) throws SQLException, AssetException;
	public ArrayList<String> viewAssets() throws SQLException, AssetException;
	public int raiseRequest(AssetRequestFormBean assetRequest)
			throws SQLException, AssetException;
	public String modifyStatus(String msg,AssetRequestBean ar) throws SQLException, AssetException;
	public ArrayList<AssetRequestBean> viewAssetRequestDetails(int assetId) throws SQLException, AssetException;
	public boolean isValidQuantity(AssetRequestBean ar) throws SQLException, AssetException;
	
}
