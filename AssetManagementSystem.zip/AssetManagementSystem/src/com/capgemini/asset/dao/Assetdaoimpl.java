package com.capgemini.asset.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capgemini.asset.bean.AssetBean;
import com.capgemini.asset.bean.AssetRequestBean;
import com.capgemini.asset.bean.AssetRequestFormBean;
import com.capgemini.asset.bean.UserBean;
import com.capgemini.asset.exception.AssetException;
import com.capgemini.asset.util.DBConnection;


public class Assetdaoimpl implements IAssetdao{
	
	
	
	
	//------------------------ 1.Asset Management System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	dataAuthentication(UserBean a)
		 - Input Parameters	:	UserBean
		 - Return Type		:	boolean
		 - Throws			:  	AssetException,SQLException
		 - Author			:	
		 - Creation Date	:	20/6/2018
		 - Description		:	Authenticating User and Admin
		 ********************************************************************************************************/
public boolean dataAuthentication(UserBean a){
		Statement stmt=null;
		boolean temp=false;
		ResultSet rs=null;
		
		try{
			Connection conn=DBConnection.getConnection();
		 stmt=conn.createStatement(); 
		rs=stmt.executeQuery(IQueryMapper.RETRIEVE_USER_DATA);
		
		if(rs!=null){
		while(rs.next()){
			//System.out.println(rs.getString(2));
		if((rs.getString(1).equals(a.getUserNameId())||rs.getString(2).equals(a.getUserNameId()))&&rs.getString(3).equals(a.getPassword())){
		temp=true;
		break;
		}
		else{
			temp=false;
		}
		}
		}
		/*if(temp==false)
		{
			throw new AssetException("Please Enter valid Credentials");
		}*/
		if(temp==true){
		a.setUserType(rs.getString(4));
		System.out.println(a.getUserType());
		}
		else
			{
			System.err.println("Please Enter valid name and password.");
			}
			}
	catch(AssetException e){
		System.out.println(e);
	}
		catch(Exception e){
		System.out.println(e);
	}
		finally{
			try{
				
			
			rs.close();
			stmt.close();
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
			}
		return temp;
}

	
//------------------------ 1.Asset Management System  --------------------------
		/*******************************************************************************************************
		 - Function Name	:	updatePassword(String username,String password)
		 - Input Parameters	:	String
		 - Return Type		:	boolean
		 - Throws			:  	AssetException,SQLException
		 - Author			:	
		 - Creation Date	:	20/6/2018
		 - Description		:	Updating password for forgotpassword option.
		 ********************************************************************************************************/

	@Override
	public boolean updatePassword(String username,String password) {
		PreparedStatement stmt=null;
		boolean temp=false;
		ResultSet rs=null;
		
		try{
			Connection conn=DBConnection.getConnection();
			stmt=conn.prepareStatement(IQueryMapper.UPDATE_PASSWORD);
			stmt.setString(1,password);
			stmt.setString(2, username);
			int queryresult=stmt.executeUpdate();
			if(queryresult==0) {
				temp=false;
			}
			else
			{
				temp=true;
			}
		
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return temp;
	}

	
	//------------------------ 1.Asset Management System  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addNewAsset(AssetBean as)
			 - Input Parameters	:	AssetBean
			 - Return Type		:	void
			 - Throws			:  	AssetException,SQLException
			 - Author			:	
			 - Creation Date	:	20/6/2018
			 - Description		:	Adding New Asset(Functionality of ADMIN)
			 ********************************************************************************************************/
	@Override
	public void addNewAsset(AssetBean as) throws SQLException,AssetException {
		Connection con=null;
		PreparedStatement stmt=null;
	
		
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.INSERT_ASSSET_DATA);
			stmt.setLong(1, as.getAssetId());
			stmt.setString(2, as.getAssetName());
			stmt.setString(3, as.getAssetDes());
			stmt.setInt(4, as.getQuantity());
			stmt.setString(5, as.getStatus());
			int queryResult=stmt.executeUpdate();
			if(queryResult==0)
			{
				throw new AssetException("Data Insertion Failed.");
			}
			else
			{
				System.out.println("Data Inserted Successfully.");
			}
			
			con.close();
		
			stmt.close();
	}

	
	//------------------------ 1.Asset Management System  --------------------------
			/*******************************************************************************************************
			 - Function Name	:	modifyAssetDetails(AssetBean as,long oldAssetId)
			 - Input Parameters	:	AssetBean,long
			 - Return Type		:	boolean
			 - Throws			:  	AssetException,SQLException
			 - Author			:	
			 - Creation Date	:	23/6/2018
			 - Description		:	Modifing Asset details.
			 ********************************************************************************************************/
	@Override
	public void modifyAssetDetails(AssetBean as,long oldAssetId) throws SQLException,
			AssetException {
	
		Connection con=null;
		PreparedStatement stmt=null;
	
		
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.UPDATE_ASSET_DATA);
			stmt.setLong(1, as.getAssetId());
			stmt.setString(2, as.getAssetName());
			stmt.setString(3, as.getAssetDes());
			stmt.setInt(4, as.getQuantity());
			stmt.setString(5, as.getStatus());
			stmt.setLong(6, oldAssetId);
			int queryResult=stmt.executeUpdate();
			if(queryResult==0)
			{
				throw new AssetException("Can,t Modify Data.");
			}
			else
			{
				System.out.println("Modification done successfully.");
			}
			con.close();
			stmt.close();
	}

	//------------------------ 1.Asset Management System  --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewRequestDetails(long assetId)
	 - Input Parameters	:	void
	 - Throws			:  	AssetException,SQLException
	 - Author			:	
	 - Creation Date	:	27/6/2018
	 - Description		:	Viewing Request for Asset
	 ********************************************************************************************************/

	@Override
public ArrayList<AssetRequestBean> viewRequestDetails(int requestId) throws SQLException,
					AssetException {
				ArrayList<AssetRequestBean> l=new ArrayList();
				Connection con=null;
				PreparedStatement stmt=null;
			
				
					con=DBConnection.getConnection();
					stmt=con.prepareStatement(IQueryMapper.HAS_REQUEST_DETAILS);
					stmt.setLong(1,requestId);
					ResultSet rs=stmt.executeQuery();
					rs.next();
					
					if(rs.getInt(1)>0){
						stmt.close();
						rs.close();
						stmt=con.prepareStatement(IQueryMapper.VIEW_MANAGER_REQUEST_DETAILS);
						stmt.setLong(1,requestId);
						rs=stmt.executeQuery();
						
						
						while(rs.next()){
							AssetRequestBean ar=new AssetRequestBean();
							ar.setRequestId(rs.getInt(1));
							ar.setAssetId(rs.getInt(2));
							ar.setAssetName(rs.getString(3));
							ar.setRequestStatus(rs.getString(4));
						l.add(ar);
						
					}
					}
					else
					{
						System.out.println("No Requests for the corresponding Request Id.");
					}
				
					con.close();
					stmt.close();
				
					return l;
}


	@Override
	public ArrayList<String> viewAssets() throws SQLException,
			AssetException {
		ArrayList<String> al=new ArrayList();
		Connection con=null;
		PreparedStatement stmt=null;
	
		
			con=DBConnection.getConnection();
			stmt=con.prepareStatement(IQueryMapper.VIEW_ASSETS);
			ResultSet rs=stmt.executeQuery();
			while(rs.next()){
				
				
				al.add(rs.getString(1));
			}
			con.close();
			stmt.close();
		return al;
	}


	@Override
	public int raiseRequest(AssetRequestFormBean assetRequest)
			throws SQLException, AssetException {
		Connection con=null;
		PreparedStatement prestmt=null;
		con=DBConnection.getConnection();
		Statement stmt;
			stmt=con.createStatement();  
	    ResultSet rs=stmt.executeQuery("select count(*) from user_sequences where sequence_name='REQ_SEQ'"); 
		rs.next();
		if(rs.getInt(1)==1){
			System.out.println("Sequence already existed");
		}
		else{
			 stmt.executeQuery(IQueryMapper.CREATE_REQ_SEQ); 
		}
		
			prestmt=con.prepareStatement(IQueryMapper.INSERT_REQUEST);
			prestmt.setInt(1,assetRequest.getEmpId());
			prestmt.setString(2,assetRequest.getAssetName());
			prestmt.setString(3,assetRequest.getAssetDes());
			prestmt.setString(4,assetRequest.getAssetPurpose());
			prestmt.setInt(5,assetRequest.getQuan());
			int queryResult=prestmt.executeUpdate();
			if(queryResult==0){
				throw new AssetException("Request not raised");
			}
			
			stmt=con.createStatement();
			rs=stmt.executeQuery("select requestid from Asset_Request WHERE empid="+assetRequest.getEmpId()); 
			rs.next();
			return rs.getInt(1);
	}


	@Override
	public ArrayList<AssetRequestBean> viewAssetRequestDetails(int assetId)
			throws SQLException, AssetException {
		Connection con=null;
		PreparedStatement prestmt=null;
		con=DBConnection.getConnection();
		ArrayList<AssetRequestBean> al=new ArrayList();
		
			prestmt=con.prepareStatement(IQueryMapper.VIEW_ASSET_REQUEST_DETAILS);
			prestmt.setInt(1,assetId);
			ResultSet rs=prestmt.executeQuery();
			while(rs.next()){
				AssetRequestBean ar=new AssetRequestBean();
				ar.setRequestId(rs.getInt(1));
				ar.setAssetId(rs.getInt(2));
				ar.setEmpid(rs.getInt(3));
				ar.setAssetName(rs.getString(4));
				ar.setAssetDes(rs.getString(5));
				ar.setQuantity(rs.getInt(6));
				al.add(ar);
			}
			
		return al;	
	}


	@Override
	public String modifyStatus(String msg,AssetRequestBean ar) throws SQLException, AssetException {
		Connection con=null;
		PreparedStatement prestmt=null;
		String str=null;
		con=DBConnection.getConnection();
		ArrayList<AssetRequestBean> al=new ArrayList();
		if(msg.equals("Accept")){
			prestmt=con.prepareStatement(IQueryMapper.UPDATE_ASSET_STATUS);
			prestmt.setInt(1,ar.getQuantity());
			prestmt.setInt(2,ar.getAssetId());
			int queryResult=prestmt.executeUpdate();
			if(queryResult==0){
				
			}
			else
			{
				str="updated";
				prestmt=con.prepareStatement(IQueryMapper.INSERT_ALLOCATED_DATA);
				prestmt.setInt(1, ar.getAssetId());
				prestmt.setInt(2,ar.getEmpid());
				prestmt.setInt(3,5);
				prestmt.executeUpdate();
				prestmt=con.prepareStatement(IQueryMapper.UPDATE_STATUS);
				prestmt.setString(1,"Allocated");
				prestmt.setInt(2, ar.getRequestId());
				prestmt.executeUpdate();
			}
		}
		else
		{
			prestmt=con.prepareStatement(IQueryMapper.UPDATE_STATUS);
			prestmt.setString(1,"Not Allocated");
			prestmt.setInt(2, ar.getRequestId());
			prestmt.executeUpdate();
		}
		
		return str;
	}


	@Override
	public boolean isValidQuantity(AssetRequestBean ar) throws SQLException,
			AssetException {
		Connection con=null;
		PreparedStatement prestmt=null;
		con=DBConnection.getConnection();
			boolean temp=false;
			prestmt=con.prepareStatement(IQueryMapper.CHECK_QUANTITY);
			prestmt.setInt(1,ar.getQuantity());
			prestmt.setInt(2,ar.getAssetId());
			ResultSet rs=prestmt.executeQuery();
			rs.next();
			if(rs.getInt(1)==1)
				temp=true;
			else
				temp=false;
			
		return temp;	
	}
		
}
		


