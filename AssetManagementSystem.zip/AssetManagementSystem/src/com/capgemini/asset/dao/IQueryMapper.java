package com.capgemini.asset.dao;

public interface IQueryMapper {
public final static String RETRIEVE_USER_DATA="select * from usermaster";
public final static String UPDATE_PASSWORD="UPDATE usermaster SET userpassword=? WHERE username=?";
public final static String INSERT_ASSSET_DATA="INSERT INTO asset VALUES(?,?,?,?,?)";
//public final static String VIEW_REQUESTS="Select * from "
public final static String UPDATE_ASSET_DATA="UPDATE asset SET assetid=?,assetname=?,assetdes=?,quantity=?,status=? where assetid=?";
public final static String HAS_REQUEST_DETAILS="SELECT count(*) from asset_request WHERE requestid=?";
public final static String VIEW_MANAGER_REQUEST_DETAILS="SELECT requestid,assetid,al.assetname,requeststatus from asset al,asset_request ar WHERE al.assetname=ar.assetname and requestid=?";
public final static String VIEW_ASSET_REQUEST_DETAILS="SELECT requestid,assetid,empid,al.assetname,al.assetdes,ar.quantity from asset al,asset_request ar WHERE al.assetname=ar.assetname and assetid=? and requeststatus='Awaiting Accept'";
public final static String VIEW_ASSETS="SELECT assetname FROM asset";
public final static String INSERT_REQUEST="INSERT INTO asset_request VALUES(req_seq.NEXTVAL,?,?,?,?,?,default)";
public final static String CREATE_REQ_SEQ="CREATE SEQUENCE req_seq START WITH 1000 NOCYCLE";
public final static String UPDATE_ASSET_STATUS="UPDATE asset SET quantity=quantity-(?) WHERE assetid=?";
public final static String INSERT_ALLOCATED_DATA="INSERT INTO asset_allocation VALUES(allocation_id.NEXTVAL,?,?,SYSDATE,SYSDATE+?)";
public final static String UPDATE_STATUS="UPDATE asset_request SET requeststatus=? WHERE requestid=?";
public final static String  CHECK_QUANTITY="SELECT COUNT(*) FROM asset WHERE quantity>0 AND quantity>? AND assetid=?";
}
