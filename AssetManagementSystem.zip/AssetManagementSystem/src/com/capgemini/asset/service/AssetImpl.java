package com.capgemini.asset.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.asset.bean.AssetBean;
import com.capgemini.asset.bean.AssetRequestBean;
import com.capgemini.asset.bean.AssetRequestFormBean;
import com.capgemini.asset.bean.UserBean;
import com.capgemini.asset.dao.*;
import com.capgemini.asset.exception.AssetException;


public class AssetImpl implements IAssetInterface{

	@Override
	public boolean isValidUsername(String name) {
	Pattern namePattern=Pattern.compile("^[A-Z][A-Za-z]{2,}$");
	Pattern idPattern=Pattern.compile("^[1-9][0-9]{5,5}$");
	Matcher nameMatcher=namePattern.matcher(name);
	Matcher idMatcher=idPattern.matcher(name);
	if(nameMatcher.matches()||idMatcher.matches())
	{
		return true;
	}
	else 
	{
		return false;
	}
	}
	@Override
	public boolean isValidPassword(String pass) {
		Pattern namePattern=Pattern.compile("^[A-Z[A-Z]{1}a-z0-9[@#$%^&*()]{1}]{8,16}$");
		Matcher nameMatcher=namePattern.matcher(pass);
		return nameMatcher.matches();
	}


	@Override
	public boolean dataAuthentication(UserBean a) {
		IAssetdao id=new Assetdaoimpl();
		boolean temp=id.dataAuthentication(a);
		return temp;
	}
	@Override
	public boolean updatePassword(String username,String password) {
		IAssetdao ie=new Assetdaoimpl();
		
		return ie.updatePassword(username,password);
		
	}
	@Override
	public void addNewAsset(AssetBean as) throws SQLException, AssetException{
		IAssetdao id=new Assetdaoimpl();
		id.addNewAsset(as);
		}
	@Override
	public void modifyAssetDetails(AssetBean as,long oldAssetId) throws SQLException,
			AssetException {
		IAssetdao id=new Assetdaoimpl();
		id.modifyAssetDetails(as,oldAssetId);
		
	}
	
	@Override
	public ArrayList<AssetRequestBean> viewRequestDetails(int requestId) throws SQLException, AssetException {
		IAssetdao id=new Assetdaoimpl();
		return id.viewRequestDetails(requestId);
	}
	@Override
	public ArrayList<String> viewAssets() throws SQLException,
			AssetException {
		IAssetdao id=new Assetdaoimpl();
		return id.viewAssets();
		
	}
	@Override
	public int raiseRequest(AssetRequestFormBean assetRequest)
			throws SQLException, AssetException {
		IAssetdao id=new Assetdaoimpl();
		return id.raiseRequest(assetRequest);
		
	}
	@Override
	public boolean isValidAssetName(ArrayList<String> al, String assetName) {
		boolean flag=false;
		for(Object o:al){
			if(o.equals(assetName)){
				flag= true;
				break;
			}
			else
			{
		flag=false;
			}
			}
		if(flag==false)
			System.err.println("Enter available asset name");
		
		return flag;
	}
	
	
	@Override
	public ArrayList<AssetRequestBean> viewAssetRequestDetails(int assetId)
			throws SQLException, AssetException {
		IAssetdao id=new Assetdaoimpl();
		return id.viewAssetRequestDetails(assetId);
		
		
	}
	@Override
	public String modifyStatus(String msg,AssetRequestBean ar) throws SQLException, AssetException{
		IAssetdao id=new Assetdaoimpl();
		return id.modifyStatus(msg,ar);
	}
	@Override
	public boolean isValidQuantity(AssetRequestBean ar) throws SQLException,
			AssetException {
		IAssetdao id=new Assetdaoimpl();
		return id.isValidQuantity(ar);
		
	}

}
