package com.capgemini.recharge.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;  

import com.capgemini.recharge.bean.RechargeBean;
	
public class RechargeDataBase implements IRechargeInterface{  
	@Override
	public String displayRechargePlans(){
	String planname = null;
	int amount=0;
	String msg = null;
	StringBuilder sb=new StringBuilder();
	try{  
	//step1 load the driver class  
	Class.forName("oracle.jdbc.driver.OracleDriver");  
	  
	//step2 create  the connection object  
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1109","training1109");  
	  
	//step3 create the statement object  
	Statement stmt=con.createStatement();  
	  
	//step4 execute query  
	ResultSet rs=stmt.executeQuery("select * from rechargeplans"); 
	if(rs!=null){
		while(rs.next()){
			planname=rs.getString(1);
			amount=rs.getInt(2);
			sb.append(planname+"      "+Integer.toString(amount)+"\n");
			//System.out.println(details);
			
		}
	}
	

	//step5 close the connection object  
	con.close();  
	  
	}catch(Exception e){ 
		msg=e.getMessage();
	}
	return sb.toString();
	  
	}

	
	

	@Override
	public void addRechargeData(RechargeBean rb) {
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con1=DriverManager.getConnection(  
					"jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1109","training1109");  
			  
			//step3 create the statement object  
			//PreparedStatement stmt=con1.prepareStatement("CREATE TABLE rechargedetailsm(recID number,name VARCHAR2(20),mobile number(20),status VARCHAR2(20),planname VARCHAR2(20),amount number(10))");   
			//  stmt.execute();
			//step4 execute query  
	//	stmt.executeQuery("CREATE TABLE rechargedetailsp(recID number,name VARCHAR2(20),mobile number(20),status VARCHAR2(20),planname VARCHAR2(20),amount number(10))"); 
		
		PreparedStatement stmt1=con1.prepareStatement("INSERT INTO rechargedetails VALUES(?,?,?,?,?,?)");  
		System.out.println(rb.getRechargeId());		
		stmt1.setInt(1,rb.getRechargeId());
				stmt1.setString(2,rb.getName());
				stmt1.setLong(3,rb.getMobileno());
				stmt1.setString(4,rb.getStatus());
				stmt1.setString(5,rb.getPlanname());
				stmt1.setInt(6,rb.getAmount());
				 
				stmt1.execute();
				
				//if(queryResult)
					//System.out.println(details);
					
				
			//step5 close the connection object  
			con1.close();  
			  
			}catch(Exception e){ 
				String msg = e.getMessage();
			}
	}

	@Override
	public int generateRechargeId() {
		int res=0;
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			//step2 create  the connection object  
			Connection con1=DriverManager.getConnection(  
					"jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1109","training1109");  
			  
			//step3 create the statement object  
			Statement stmt=con1.createStatement();  
			  
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select re_seq.NEXTVAL from dual"); 
			
				rs.next();
			 res=rs.getInt(1);
					//System.out.println(details);
					
				
			//step5 close the connection object  
			con1.close();  
			  
			}catch(Exception e){ 
				String msg = e.getMessage();
			}
		return res;
	}

	@Override
	public String getDetails(int recharge) {
		String planname = null;
		int amount=0;
		String msg = null;
		int rechid;
		long mobile;
		String name=null,status;
		
		StringBuilder sb=new StringBuilder();
		try{  
		//step1 load the driver class  
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl","trg1109","training1109");  
		  
		//step3 create the statement object  
		Statement stmt=con.createStatement();  
		  
		//step4 execute query  
		ResultSet rs=stmt.executeQuery("select * from rechargedetails where recID="+recharge); 
		if(rs!=null){
			while(rs.next()){
				rechid=rs.getInt(1);
				name=rs.getString(2);
				mobile=rs.getLong(3);
				status=rs.getString(4);
				planname=rs.getString(5);
				amount=rs.getInt(6);
				
				
				sb.append("Recharge id"+rechid+"\nUser Name"+name+"\nMobile Number"+mobile+"\nStatus"+status+"\nRechargePlan Name"+planname+"\nRecharge Amount"+Integer.toString(amount)+"\n");
				//System.out.println(details);
				
			}
		}
		

		//step5 close the connection object  
		con.close();  
		  
		}catch(Exception e){ 
			msg=e.getMessage();
		}
	return sb.toString();
	}

	
		
	
}
